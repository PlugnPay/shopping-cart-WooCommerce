<?php
/*
 * Plugin Name: PlugnPay API Gift Card Payment Gateway For WooCommerce
 * Plugin URI: https://github.com/PlugnPay/shopping-cart-WooCommerce
 * Description: Extends WooCommerce to Process API Gift Card Payments with PlugnPay gateway.
 * Version: 1.1.3
 * Author: PlugnPay
 * Author URI: http://www.plugnpay.com
 * Text Domain: woocommerce_plugnpay_api_gc
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * License: GPL2
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
*/

add_action('before_woocommerce_init', 'woocommerce_plugnpay_api_gc_declare_compatibility');

function woocommerce_plugnpay_api_gc_declare_compatibility() {
  if (!class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
    return;
  }

  \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
}

add_action('plugins_loaded', 'woocommerce_plugnpay_api_gc_init', 0);

function woocommerce_plugnpay_api_gc_init() {
  if (!class_exists('WC_Payment_Gateway')) {
    return;
  }

  load_plugin_textdomain('woocommerce_plugnpay_api_gc', false, dirname(plugin_basename(__FILE__)) . '/languages');

  class WC_Plugnpay_API_GC_Gateway extends WC_Payment_Gateway {

    public function __construct() {
      $this->id                 = 'plugnpay_api_gc';
      $this->method_title       = __('PlugnPay API GC', 'woocommerce_plugnpay_api_gc');
      $this->method_description = __('Accept Gift Card payments via API payment method, directly in WooCommerce.', 'woocommerce_plugnpay_api_gc');
      $this->icon               = '';
      $this->has_fields         = true;
      $this->supports           = array('products');
      $this->init_form_fields();
      $this->init_settings();
      $this->title              = $this->settings['title'];
      $this->description        = $this->settings['description'];

      $wc_version = defined('WC_VERSION') ? WC_VERSION : (defined('WOOCOMMERCE_VERSION') ? WOOCOMMERCE_VERSION : '0');
      if (version_compare($wc_version, '2.0.0', '>=')) {
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
      }
      else {
        add_action('woocommerce_update_options_payment_gateways', array($this, 'process_admin_options'));
      }

      add_action('woocommerce_receipt_plugnpay_api_gc', array($this, 'receipt_page'));
      add_action('woocommerce_thankyou_plugnpay_api_gc', array($this, 'thankyou_page'));
      add_action('wp_enqueue_scripts', array($this, 'enqueue_checkout_assets'));
    }

    /**
    * Checkout assets for payment fields.
    **/
    public function enqueue_checkout_assets() {
      if (!is_checkout() && !is_wc_endpoint_url('order-pay')) {
        return;
      }

      wp_enqueue_style(
        'plugnpay-api-gc-checkout',
        plugins_url('assets/css/checkout.css', __FILE__),
        array(),
        '1.1.3'
      );

      wp_enqueue_script(
        'plugnpay-api-gc-checkout',
        plugins_url('assets/js/checkout.js', __FILE__),
        array('jquery'),
        '1.1.3',
        true
      );

      wp_localize_script(
        'plugnpay-api-gc-checkout',
        'plugnpayApiGcCheckout',
        array(
          'i18n' => array(
            'giftCardNumberInvalid'       => esc_html__('(Gift Card Number) is not valid.', 'woocommerce_plugnpay_api_gc'),
            'giftCardSecurityCodeInvalid' => esc_html__('(Gift Card Verification Number) is not valid.', 'woocommerce_plugnpay_api_gc'),
          ),
        )
      );
    }

    function init_form_fields() {
      $this->form_fields = array(
          'enabled'         => array(
              'title'          => __('Enable/Disable', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'checkbox',
              'label'          => __('Enable PlugnPay API GC Payment Module.', 'woocommerce_plugnpay_api_gc'),
              'default'        => 'no'),
          'title'           => array(
              'title'          => __('Title:', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'text',
              'description'    => __('This controls the title which the user sees during checkout.', 'woocommerce_plugnpay_api_gc'),
              'default'        => __('Pay By Gift Card', 'woocommerce_plugnpay_api_gc')),
          'description'     => array(
              'title'          => __('Description:', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'textarea',
              'description'    => __('This controls the description which the user sees during checkout.', 'woocommerce_plugnpay_api_gc'),
              'default'        => __('Pay securely with Gift Card through PlugnPay Secure Servers.', 'woocommerce_plugnpay_api_gc')),
          'gateway_account' => array(
              'title'          => __('Gateway Account', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'text',
              'description'    => __('Username issued by PlugnPay at time of sign up.', 'woocommerce_plugnpay_api_gc')),
          'remote_password' => array(
              'title'          => __('Remote Client Password', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'password',
              'description'    => __('Remote Client Password is created within your PlugnPay Security Administration area.', 'woocommerce_plugnpay_api_gc')),
          'success_message' => array(
              'title'          => __('Transaction Success Message', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'textarea',
              'description'    => __('Message to be displayed on successful transaction.', 'woocommerce_plugnpay_api_gc'),
              'default'        => __('Your payment has been processed successfully.', 'woocommerce_plugnpay_api_gc')),
          'failed_message'  => array(
              'title'          => __('Transaction Failed Message', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'textarea',
              'description'    => __('Message to be displayed on failed transaction.', 'woocommerce_plugnpay_api_gc'),
              'default'        => __('Your transaction has been declined.', 'woocommerce_plugnpay_api_gc')),
          'post_auth'       => array(
              'title'          => __('Transaction Settlement', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'select',
              'options'        => array('yes'=>'Authorize and Settle', 'no'=>'Authorize Only'),
              'description'    => __('Transaction Settlement. If you are not sure what to use set to Authorize and Settle.', 'woocommerce_plugnpay_api_gc')),
          'giftcard_format' => array(
              'title'          => __('Giftcard Format', 'woocommerce_plugnpay_api_gc'),
              'type'           => 'select',
              'options'        => array('luhn10'=>'Perform LUHN-10-Check', 'skip'=>'Skip LUHN-10 Check'),
              'description'    => __('Specify if your giftcard numbers are LUHN-10 or not.', 'woocommerce_plugnpay_api_gc')),
       );
    }

    public function process_admin_options() {
      $saved_password = $this->get_option('remote_password');
      parent::process_admin_options();
      if ('' === $this->get_option('remote_password') && '' !== $saved_password) {
        $this->update_option('remote_password', $saved_password);
      }
    }

    public function get_icon() {
      $icon_url = plugins_url('images/logo.png', __FILE__);
      $icons = '<span class="plugnpay-gc-icons"><img src="' . esc_url($icon_url) . '" alt="' . esc_attr__('Gift Card', 'woocommerce_plugnpay_api_gc') . '" /></span>';

      return apply_filters('woocommerce_gateway_icon', $icons, $this->id);
    }

    public function admin_options() {
      echo '<h3>'.esc_html__('PlugnPay API GC Payment Gateway', 'woocommerce_plugnpay_api_gc').'</h3>';
      echo '<p>'.esc_html__('PlugnPay is a popular payment gateway for online payment processing', 'woocommerce_plugnpay_api_gc').'</p>';
      echo '<table class="form-table">';
      $this->generate_settings_html();
      echo '</table>';
    }

    function payment_fields() {
      if ($this->description) {
        echo '<div class="plugnpay-gc-description">' . wpautop(wptexturize($this->description)) . '</div>';
      }

      echo '<fieldset class="plugnpay-gc-fields wc-payment-form">';
      echo '<legend class="screen-reader-text">' . esc_html__('Gift card details', 'woocommerce_plugnpay_api_gc') . '</legend>';
      $this->render_giftcard_fields();
      echo '</fieldset>';
    }

    /**
    * Render gift card number and security code on one row.
    **/
    private function render_giftcard_fields() {
      $required_mark = ' <abbr class="required" title="' . esc_attr__('required', 'woocommerce_plugnpay_api_gc') . '">*</abbr>';

      echo '<p class="form-row form-row-wide plugnpay-gc-giftcard-row">';
      echo '<span class="plugnpay-gc-giftcard-fields">';

      echo '<span class="plugnpay-gc-giftcard-field plugnpay-gc-giftcard-field-number">';
      echo '<label for="pnp_mpgiftcard">' . esc_html__('Gift card number', 'woocommerce_plugnpay_api_gc') . $required_mark . '</label>';
      echo '<input type="tel" class="input-text" name="pnp_mpgiftcard" id="pnp_mpgiftcard" maxlength="20" minlength="1" pattern="[0-9]{1,20}" inputmode="numeric" autocomplete="off" required />';
      echo '</span>';

      echo '<span class="plugnpay-gc-giftcard-field plugnpay-gc-giftcard-field-cvv">';
      echo '<label for="pnp_mpcvv">' . esc_html__('Security code', 'woocommerce_plugnpay_api_gc') . $required_mark . '</label>';
      echo '<input type="tel" class="input-text" name="pnp_mpcvv" id="pnp_mpcvv" maxlength="4" minlength="3" pattern="[0-9]{3,4}" inputmode="numeric" autocomplete="off" placeholder="CVV" required />';
      echo '</span>';

      echo '</span></p>';
    }

    public function validate_fields() {
      $valid = true;
      $mpgiftcard = $this->get_posted_field('pnp_mpgiftcard');
      $mpcvv = $this->get_posted_field('pnp_mpcvv');

      if ($this->settings['giftcard_format'] === 'luhn10') {
        if (!$this->isGiftCardNumber($mpgiftcard)) {
          wc_add_notice(__('(Gift Card Number) is not valid.', 'woocommerce_plugnpay_api_gc'), 'error');
          $valid = false;
        }
      }
      elseif (!$this->isNumericField($mpgiftcard, 1, 20)) {
        wc_add_notice(__('(Gift Card Number) is not valid.', 'woocommerce_plugnpay_api_gc'), 'error');
        $valid = false;
      }

      if (!$this->isCCVNumber($mpcvv)) {
        wc_add_notice(__('(Gift Card Verification Number) is not valid.', 'woocommerce_plugnpay_api_gc'), 'error');
        $valid = false;
      }

      return $valid;
    }

    private function get_posted_field($key) {
      if (!isset($_POST[$key])) {
        return '';
      }
      return sanitize_text_field(wp_unslash($_POST[$key]));
    }

    private function get_order_amount($order) {
      return wc_format_decimal($order->get_total(), 2);
    }

    private function isNumericField($toCheck, $min_length, $max_length) {
      if (!ctype_digit($toCheck)) {
        return false;
      }

      $length = strlen($toCheck);
      return ($length >= $min_length && $length <= $max_length);
    }

    private function isGiftCardNumber($toCheck) {
      if (!ctype_digit($toCheck)) {
        return false;
      }

      $number = $toCheck;
      $strlen = strlen($number);
      $sum    = 0;

      if ($strlen < 13) {
        return false;
      }

      for ($i=0; $i < $strlen; $i++) {
        $digit = substr($number, $strlen - $i - 1, 1);
        if ($i % 2 == 1) {
          $sub_total = $digit * 2;
          if ($sub_total > 9) {
            $sub_total = 1 + ($sub_total - 10);
          }
        }
        else {
          $sub_total = $digit;
        }
        $sum += $sub_total;
      }

      return ($sum > 0 && $sum % 10 == 0);
    }

    private function isCCVNumber($toCheck) {
      return (bool) preg_match('/^\d{3,4}$/', $toCheck);
    }

    public function thankyou_page($order_id) {
      /* nothing to do here... */
    }

    function receipt_page($order) {
      echo '<p>'.esc_html__('Thank you for your order.', 'woocommerce_plugnpay_api_gc').'</p>';
    }

    function process_payment($order_id) {
      $order = wc_get_order($order_id);

      if (!$order) {
        wc_add_notice(__('(Transaction Error) Invalid order.', 'woocommerce_plugnpay_api_gc'), 'error');
        return array('result' => 'failure');
      }

      if (empty($this->settings['gateway_account']) || empty($this->settings['remote_password'])) {
        wc_add_notice(__('(Transaction Error) Payment gateway is not configured.', 'woocommerce_plugnpay_api_gc'), 'error');
        return array('result' => 'failure');
      }

      $params = $this->generate_plugnpay_api_gc_params($order);

      $post_string = '';
      foreach ($params as $key => $value) {
        $post_string .= "$key=" . urlencode($value) . '&';
      }
      $post_string = rtrim($post_string, '&');

      $request = curl_init('https://pay1.plugnpay.com/payment/pnpremote.cgi');
      curl_setopt($request, CURLOPT_HEADER, 0);
      curl_setopt($request, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($request, CURLOPT_POSTFIELDS, $post_string);
      curl_setopt($request, CURLOPT_SSL_VERIFYPEER, true);
      curl_setopt($request, CURLOPT_SSL_VERIFYHOST, 2);
      curl_setopt($request, CURLOPT_TIMEOUT, 60);
      curl_setopt($request, CURLOPT_CONNECTTIMEOUT, 30);
      $post_response = curl_exec($request);
      $curl_error = curl_error($request);
      curl_close($request);

      if ($post_response === false) {
        $order->add_order_note($this->settings['failed_message'] . ' cURL error: ' . $curl_error);
        $order->update_status('failed');
        wc_add_notice(__('(Transaction Error) Error connecting to payment gateway.', 'woocommerce_plugnpay_api_gc'), 'error');
        return array('result' => 'failure');
      }

      parse_str($post_response, $response);

      if (!empty($response['FinalStatus'])) {
        if (($response['FinalStatus'] == 'success') || ($response['FinalStatus'] == 'pending')) {
          if ($order->get_status() != 'completed') {
            $transaction_id = isset($response['orderID']) ? $response['orderID'] : '';
            $order->payment_complete($transaction_id);
            WC()->cart->empty_cart();
            $merr_msg = isset($response['MErrMsg']) ? $response['MErrMsg'] : '';
            $order->add_order_note($this->settings['success_message'] . $merr_msg . ' Transaction ID: ' . $transaction_id);
          }
          return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url($order)
          );
        }

        $merr_msg = isset($response['MErrMsg']) ? $response['MErrMsg'] : '';
        $order->add_order_note($this->settings['failed_message'] . $merr_msg);
        $order->update_status('failed');
        wc_add_notice(sprintf(__('(Transaction Error) %s', 'woocommerce_plugnpay_api_gc'), $merr_msg), 'error');
        return array('result' => 'failure');
      }

      $order->add_order_note($this->settings['failed_message']);
      $order->update_status('failed');
      wc_add_notice(__('(Transaction Error) Error processing payment.', 'woocommerce_plugnpay_api_gc'), 'error');
      return array('result' => 'failure');
    }

    public function generate_plugnpay_api_gc_params($order) {
      $order_amount = $this->get_order_amount($order);

      $plugnpayapi_args = array(
        'publisher-name'        => strtolower($this->settings['gateway_account']),
        'publisher-password'    => $this->settings['remote_password'],
        'client'                => 'WooCommerce_API_GC',
        'mode'                  => 'auth',

        'order-id'              => $order->get_id(),
        'card-amount'           => $order_amount,
        'currency'              => strtoupper($order->get_currency()),

        'paymethod'             => 'credit',
        'mpgiftcard'            => $this->get_posted_field('pnp_mpgiftcard'),
        'mpcvv'                 => $this->get_posted_field('pnp_mpcvv'),

        'card-name'             => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
        'card-company'          => $order->get_billing_company(),
        'card-address1'         => $order->get_billing_address_1(),
        'card-address2'         => $order->get_billing_address_2(),
        'card-city'             => $order->get_billing_city(),
        'card-state'            => $order->get_billing_state(),
        'card-zip'              => $order->get_billing_postcode(),
        'card-country'          => $order->get_billing_country(),
        'phone'                 => $order->get_billing_phone(),
        'email'                 => $order->get_billing_email(),

        'shipinfo'              => '1',
        'shipname'              => $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
        'company'               => $order->get_shipping_company(),
        'address1'              => $order->get_shipping_address_1(),
        'address2'              => $order->get_shipping_address_2(),
        'city'                  => $order->get_shipping_city(),
        'state'                 => $order->get_shipping_state(),
        'zip'                   => $order->get_shipping_postcode(),
        'country'               => $order->get_shipping_country(),
      );

      if ($this->settings['post_auth'] == 'yes') {
        $plugnpayapi_args['authtype'] = 'authpostauth';
      }
      else {
        $plugnpayapi_args['authtype'] = 'authonly';
      }

      return $plugnpayapi_args;
    }
  }

  function woocommerce_add_plugnpay_api_gc_gateway($methods) {
    $methods[] = 'WC_Plugnpay_API_GC_Gateway';
    return $methods;
  }

  add_filter('woocommerce_payment_gateways', 'woocommerce_add_plugnpay_api_gc_gateway');
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'plugnpay_gc_action_links');

function plugnpay_gc_action_links ($links) {
  $gateway_links = array(
    '<a href="http://www.gatewaystatus.com/" target="_blank">Gateway Status</a>',
    '<a href="https://helpdesk.plugnpay.com/" target="_blank">Online Helpdesk</a>',
    '<a href="https://pay1.plugnpay.com/admin/" target="_blank">Merchant Admin</a>'
  );
  return array_merge($links, $gateway_links);
}

?>
