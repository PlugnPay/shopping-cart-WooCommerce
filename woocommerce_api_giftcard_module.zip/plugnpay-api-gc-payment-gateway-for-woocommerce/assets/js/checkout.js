(function ($) {
  'use strict';

  var fieldRules = {
    pnp_mpgiftcard: {
      required: true,
      minLength: 1,
      maxLength: 20,
      i18nKey: 'giftCardNumberInvalid'
    },
    pnp_mpcvv: {
      required: true,
      minLength: 3,
      maxLength: 4,
      i18nKey: 'giftCardSecurityCodeInvalid'
    }
  };

  function digitsOnly(value) {
    return (value || '').replace(/\D/g, '');
  }

  function showCheckoutError(message) {
    var $notices = $('.woocommerce-NoticeGroup-checkout, form.checkout .woocommerce-notices-wrapper:first');

    if (!$notices.length) {
      $notices = $('form.checkout');
    }

    $notices.html(
      '<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">' +
        '<div class="woocommerce-error" role="alert">' + message + '</div>' +
      '</div>'
    );

    $('html, body').animate({
      scrollTop: $notices.offset().top - 100
    }, 300);

    $(document.body).trigger('checkout_error');
  }

  function clearFieldError($field) {
    $field.removeClass('plugnpay-gc-field-invalid');
    $field.removeAttr('aria-invalid');
  }

  function setFieldError($field) {
    $field.addClass('plugnpay-gc-field-invalid');
    $field.attr('aria-invalid', 'true');
  }

  function isDigitsOnly(value) {
    return /^\d+$/.test(value);
  }

  function validateField($field, rules, showNotice) {
    var value = $field.val();

    if (rules.required && value === '') {
      setFieldError($field);
      if (showNotice) {
        showCheckoutError(plugnpayApiGcCheckout.i18n[rules.i18nKey]);
      }
      return false;
    }

    if (!rules.required && value === '') {
      clearFieldError($field);
      return true;
    }

    if (!isDigitsOnly(value)) {
      setFieldError($field);
      if (showNotice) {
        showCheckoutError(plugnpayApiGcCheckout.i18n[rules.i18nKey]);
      }
      return false;
    }

    if (value.length < rules.minLength || value.length > rules.maxLength) {
      setFieldError($field);
      if (showNotice) {
        showCheckoutError(plugnpayApiGcCheckout.i18n[rules.i18nKey]);
      }
      return false;
    }

    clearFieldError($field);
    return true;
  }

  function bindNumericField(fieldId, rules) {
    var $field = $('#' + fieldId);

    if (!$field.length) {
      return;
    }

    $field.on('input', function () {
      var sanitized = digitsOnly(this.value);

      if (rules.maxLength) {
        sanitized = sanitized.slice(0, rules.maxLength);
      }

      this.value = sanitized;
      clearFieldError($(this));
    });

    $field.on('blur', function () {
      if ($(this).val() !== '') {
        validateField($(this), rules, false);
      }
    });
  }

  function validateCheckoutFields(showNotice) {
    var isValid = true;

    $.each(fieldRules, function (fieldId, rules) {
      var $field = $('#' + fieldId);

      if (!$field.length) {
        return;
      }

      if (!validateField($field, rules, showNotice)) {
        isValid = false;
      }
    });

    return isValid;
  }

  $(function () {
    $.each(fieldRules, function (fieldId, rules) {
      bindNumericField(fieldId, rules);
    });

    $(document.body).on('checkout_place_order_plugnpay_api_gc', function () {
      return validateCheckoutFields(true);
    });
  });
}(jQuery));
