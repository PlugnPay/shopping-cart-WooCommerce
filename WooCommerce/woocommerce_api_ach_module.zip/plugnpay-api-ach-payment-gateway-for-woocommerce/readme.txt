﻿=== Plugin Name ===
PlugnPay API ACH/eCheck Payment Gateway For WooCommerce
Contributors: PlugnPay
Site link: https://www.plugnpay.com
Tags: woocommerce, plugnpay, payment, gateway, API, ACH, eCheck, checking, savings
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 1.2.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.txt

Plugin extends the functionality of WooCommerce to accept payments from checking accounts on your checkout page, using PlugnPay's API payment method.

== Description ==

PlugnPay API ACH/eCheck Payment Gateway for WooCommerce makes your website ready to use PlugnPay's API payment method, to accept checking and savings account payments on your ecommerce store checkout page.

PlugnPay is a widely used payment gateway to process payments online, including ACH/eCheck payments.

Requires WordPress 6.0+, WooCommerce 8.0+, PHP 8.1+, and HTTPS on the storefront. Collecting bank account data onsite increases compliance scope versus hosted Smart Screens.

WooCommerce 8.x Compatible (classic checkout). This module does not support WooCommerce Cart/Checkout Blocks.

= Features =
Few features of this plugin:

1. Accept ACH/eCheck payments right on your website.
2. No redirecting to other URL.
3. Easy to install and configure
4. Option to configure success & failure message
5. HTTPS required; Authorization Verification Hash (SHA-256) required
6. Remote Client Password and hash keys stored encrypted at rest
7. Optional divert payments based upon currency selected

== Installation ==
Easy steps to install the plugin:

To install the plugin:

1. Login to your WordPress admin area
2. Go to Plugins => Add new
3. Click on the 'Upload Plugin' button
4. Click on the 'Browse' button & select this payment module's zip file
5. Click on the 'Install Now' button.
6. Once installed, click on the 'Activate Button'

To configure this checkout option:

7. Go to WooCommerce => Settings
8. On the 'Settings' page, select 'Checkout' tab.
9. Under 'Payment Gateways' you will find all the available gateways, select 'PlugnPay API ACH' option
10. On this page you will find options to configure the plugin for use with WooCommerce
11. Modify the configurable elements accordingly
[* NOTE: At minimum, check the Enable checkbox & enter your username into the Gateway Account field and your Remote Client Password. All other fields are optional.]

---------------------------------------------
Enable/Disable: Used to enable/disable this payment ability, once the plug-in itself has been activated.

Title: This will appear on checkout page as name for this payment gateway

Description: This will appear on checkout page as description for this payment gateway

Gateway Account: This is the username provided to you by PlugnPay. (Note: This is the same username used to login to the PlugnPay Merchant Administration area.)

Remote Client Password: This is an API password you explicitly set within your PlugnPay account's Security Administration area. (Note: This is NOT the same password used to login to the PlugnPay Merchant Administration area.)

Transaction Success Message: This message will appear upon successful transaction. You can customize this message as per your need.

Transaction Failed Message: This message will appear when transaction will get failed/declined at payment gateway.

Transaction Settlement: Allows you to specify if approved transactions should be automatically marked for settlement.

Authorization Hash: Required. Enable Authorization Verification Hash (SHA-256) in both this module and your PlugnPay account.

Authorization Hash Key: Required. Enter the Verification Key from PlugnPay Security Administration. Leave blank to keep the current key. If using Divert Currency, list each currency with its associated key [i.e. USD:key1,BBD:key2,CAD:key3].

Authorization Hash Fields: Fieldset to use with authhash validation. (NOTE: This must match the fields selected with your PlugnPay account.)

Divert Currency: Use to enable/disable ability to redirect payments to a different gateway account for specific currency types.

Divert Accounts: List currency code, username & Remote Client Password to divert specific payments to. [i.e. USD:username1:abcd1234,BBD:username2:efgh2345,CAD:username3:ijkl3456] Legacy two-part entries (USD:username) use the default Remote Client Password. Currency codes not listed use default Gateway Account.
---------------------------------------------

12. once completed. click on the 'Save Changes' button to make those adjustments active immediately.

== Frequently Asked Questions ==
= Is SSL Required to use this plugin? =
Yes, SSL is required.

= Does this plugin support WooCommerce Checkout Blocks? =
No. Use classic checkout. See the main repository README for how to disable Cart/Checkout Blocks.

= What order status is used for pending eCheck authorizations? =
Orders with a pending gateway response are placed on-hold until settlement completes.

== Screenshots ==

== Changelog ==
= 1.2.0 =
* PCI DSS: require Authorization Hash (SHA-256) and block checkout if it is not configured
* PCI DSS: require PHP 8.1+ and HTTPS on the storefront (local/development excepted)
* PCI DSS: encrypt Remote Client Password and hash keys at rest; do not echo secrets in admin password fields
* PCI DSS: restrict cURL to HTTPS; require WooCommerce 8.0+
* Stop logging divert-account entries that can contain passwords
* Add automated tests for hash and secret storage

= 1.1.8 =
* Align checkout field layout with API CC module; add input hints and inputmode
* Make check number optional; strip non-digits from routing/account numbers
* Pending eCheck responses set order to on-hold instead of completed
* Legacy divert account format (currency:username) falls back to default password
* Add WC_Logger gateway logging (no sensitive payment data logged)
* Declare WooCommerce Blocks incompatibility; add Requires Plugins header
* Remove broken image asset references; remove unused legacy hooks
* Expand readme documentation

= 1.1.7 =
* Modernize WooCommerce order API usage (wc_get_order, getters, HPOS compatibility)
* Fix auth hash amount mismatch with card-amount field; fix undefined order id in auth hash
* Enable SSL certificate verification for gateway requests
* Fix validate_fields and process_payment return handling
* Sanitize posted payment fields; validate account type and classification
* Show ACH fields even when description is empty
* Extend Divert Currency to set Remote Client Password per account listed
* Extend Authorization Verification Hash Key to store different keys per currency
* Use password field for remote client password; use WC_Geolocation for IP detection
* Add acct_code field; add cURL timeout and connection error handling

= 1.1.6 =
* Fixed Authorization Hash Fields order

= 1.1.5 =
* Added Authorization Verification Hash ability

= 1.1.4 =
* Minor bug fixes & code clean-up

= 1.1.3 =
* Added Divert Currency ability
* Minor bug fixes & code clean-up

= 1.1.2 =
* Enhanced currency support, to work with multi-currency plug-ins
* Cleaned up some code & documentation
* Added customer's IP address to gateway API call

= 1.1.1 =
* Checkout return URL adjustment

= 1.1.0 =
* Initial Public Version

= 1.0.0 =
* First Version

== Upgrade Notice ==
= 1.2.0 =
Upgrade is required. Authorization Hash (SHA-256) and HTTPS are now required. PHP 8.1 or higher is required.

== Arbitrary section ==
